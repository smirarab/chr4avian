#!/usr/bin/env python

#############################################################################
##  this file is part of the TripletVoting package
##  see LICENSE for terms and conditions of usage.
#############################################################################

PROGRAM_NAME = "TripletVoting"
PROGRAM_AUTHOR = ["Uyen Mai","Siavash Mirarab"]
PROGRAM_LICENSE = "GNU General Public License, version 3"
PROGRAM_VERSION = "1.1"
PROGRAM_YEAR = "2021"
PROGRAM_INSTITUTE = "Department of Computer Science and Engineering, University of California at San Diego"
