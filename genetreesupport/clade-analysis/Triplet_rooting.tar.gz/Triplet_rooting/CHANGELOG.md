* Version 1.2:
	* Change the normalization skim of the triplet score to avoid underflow in large trees with sampling
	* Clean up: remove obsolete options in many functions
* Version 1.1:
    	* Fix the noeol issue in output file
	* Optimize function `complete_gene_trees` of module `tripVote.placement_lib` 
	* Add `placement_taxa` option

